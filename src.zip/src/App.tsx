import {Routes,Route} from "react-router-dom" 

function App() {

  return (
    <>
    <Routes>
    <div className="container">
      <Route path='/' element={<StudentList/>} />
    </div>
    </Routes>
         
        
      
    </>
  )
}

export default App

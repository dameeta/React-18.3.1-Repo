export interface IStudents{
   id : number;
   name: string;
   username : string;
   email: string;
   address: Address;
   phone: string;
   university : University; 

}
export interface Address{

    streetname: string;
    city: string;
    zipcode: string;

}
export interface University{
    name: string;
    location : string;
    
}
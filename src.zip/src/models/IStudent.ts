export interface IStudent{
    rno: number;
    stname :string;
    course:string;
    age:number;
}